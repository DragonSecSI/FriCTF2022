<?php
    $secret="was here";