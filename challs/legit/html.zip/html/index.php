<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Calculator</title>
</head>
    <body>
        <h1>My Calculator</h1>
        <p>I just figured out how to use <a href="https://git-scm.com/docs/git" target="_blank">git</a>! So I created my first ever webapp</p>
        <form action="index.php" method="post">
            <input type="number" name="num1">
            <select name="operator">
                <option disabled selected value>&lt;operation&gt;</option>
                <option>Add</option>
                <option>Subtract</option>
                <option>Multiply</option>
                <option>Divide</option>
            </select>
            <input type="number" name="num2">
            <br>
            <button type="submit" name="submit" value="submit">Calculate</button>
        </form>
        <?php
            include 'secret.php';
            if (isset($_POST['submit'])) {
                echo "<p>The answer is:</p>";
                $result1 = $_POST['num1'];
                $result2 = $_POST['num2'];
                $operator = $_POST['operator'];
                switch ($operator) {
                    case "None":
                        echo "You need to select a method!";
                        break;
                    case "Add":
                        echo $result1 + $result2;
                        break;
                    case "Subtract":
                        echo $result1 - $result2;
                        break;
                    case "Multiply":
                        echo $result1 * $result2;
                        break;
                    case "Divide":
                        echo $result1 / $result2;
                        break;
                    default:
                        echo "You need to select a method!";
                        break;
                }
                echo "</br><p>The secret: ". $secret . "</p>";
            }
        ?>
    </body>
</html>